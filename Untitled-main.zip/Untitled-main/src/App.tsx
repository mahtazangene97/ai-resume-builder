import { useCallback, useEffect, useRef, useState } from "react";

const API_URL = "https://mahtazangene.app.n8n.cloud/webhook/resume-builder";

type SectionKey =
  | "personalInfo"
  | "summary"
  | "experience"
  | "education"
  | "skills"
  | "projects"
  | "certifications";

type PersonalInfo = {
  fullName: string;
  email: string;
  phone: string;
  location: string;
};

type Experience = {
  id: string;
  role: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string;
  description: string;
};

type Education = {
  id: string;
  school: string;
  degree: string;
  startDate: string;
  endDate: string;
  details: string;
};

type Project = {
  id: string;
  name: string;
  link: string;
  description: string;
};

type Certification = {
  id: string;
  name: string;
  issuer: string;
  date: string;
};

type ResumeData = {
  personalInfo: PersonalInfo;
  summary: string;
  experience: Experience[];
  education: Education[];
  skills: string[];
  projects: Project[];
  certifications: Certification[];
};

type LegacyResumeData = ResumeData & {
  personal_info?: PersonalInfo;
};

type Suggestions = Record<SectionKey, string[]>;
type Scores = Record<SectionKey, number>;

const sectionKeys: SectionKey[] = [
  "personalInfo",
  "summary",
  "experience",
  "education",
  "skills",
  "projects",
  "certifications",
];

const sectionLabels: Record<SectionKey, string> = {
  personalInfo: "Personal information",
  summary: "Professional summary",
  experience: "Experience",
  education: "Education",
  skills: "Skills",
  projects: "Projects",
  certifications: "Certifications",
};

const blankSuggestions: Suggestions = {
  personalInfo: [],
  summary: [],
  experience: [],
  education: [],
  skills: [],
  projects: [],
  certifications: [],
};

const blankScores: Scores = {
  personalInfo: 0,
  summary: 0,
  experience: 0,
  education: 0,
  skills: 0,
  projects: 0,
  certifications: 0,
};

const createId = () =>
  typeof crypto !== "undefined" && crypto.randomUUID
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;

const emptyPersonalInfo: PersonalInfo = {
  fullName: "",
  email: "",
  phone: "",
  location: "",
};

const getPersonalInfo = (resume: ResumeData) =>
  resume.personalInfo ?? (resume as LegacyResumeData).personal_info ?? emptyPersonalInfo;

const getResumePayload = (resumeId: string, resume: ResumeData) => ({
  resumeId,
  personalInfo: getPersonalInfo(resume),
  summary: resume.summary,
  experience: resume.experience,
  education: resume.education,
  skills: resume.skills,
  projects: resume.projects,
  certifications: resume.certifications,
});

const initialResume: ResumeData = {
  personalInfo: {
    fullName: "Alex Morgan",
    email: "alex.morgan@email.com",
    phone: "+1 415 555 0138",
    location: "San Francisco, CA",
  },
  summary:
    "Product designer focused on turning complex workflows into simple, useful experiences. I combine customer insight, systems thinking, and close collaboration to ship products that create measurable impact.",
  experience: [
    {
      id: createId(),
      role: "Senior Product Designer",
      company: "Northstar Labs",
      location: "San Francisco, CA",
      startDate: "2021",
      endDate: "Present",
      description:
        "Led end-to-end design for a B2B analytics platform used by more than 12,000 teams. Built a scalable design system and partnered with product and engineering to increase activation by 28%.",
    },
  ],
  education: [
    {
      id: createId(),
      school: "California College of the Arts",
      degree: "BFA, Interaction Design",
      startDate: "2013",
      endDate: "2017",
      details: "Graduated with distinction",
    },
  ],
  skills: [
    "Product strategy",
    "Interaction design",
    "Prototyping",
    "Design systems",
    "User research",
  ],
  projects: [
    {
      id: createId(),
      name: "Atlas Design System",
      link: "atlas.design",
      description:
        "Created a cross-platform component library that reduced design and engineering delivery time by 35%.",
    },
  ],
  certifications: [
    {
      id: createId(),
      name: "Human-Computer Interaction",
      issuer: "Interaction Design Foundation",
      date: "2020",
    },
  ],
};

function Icon({
  name,
  className = "size-5",
}: {
  name:
    | "sparkle"
    | "save"
    | "plus"
    | "trash"
    | "check"
    | "document"
    | "mail"
    | "phone"
    | "pin"
    | "link"
    | "download";
  className?: string;
}) {
  const paths = {
    sparkle: (
      <>
        <path d="M12 3l1.4 4.1L17.5 8.5l-4.1 1.4L12 14l-1.4-4.1-4.1-1.4 4.1-1.4L12 3Z" />
        <path d="m18.5 14 .7 2.1 2.1.7-2.1.7-.7 2.1-.7-2.1-2.1-.7 2.1-.7.7-2.1Z" />
        <path d="m5.5 14 .7 2.1 2.1.7-2.1.7-.7 2.1-.7-2.1-2.1-.7 2.1-.7.7-2.1Z" />
      </>
    ),
    save: (
      <>
        <path d="M5 3.5h12l3.5 3.5v13.5h-17v-17Z" />
        <path d="M7.5 3.5v6h9v-6M8 20.5v-7h8v7" />
      </>
    ),
    plus: <path d="M12 5v14M5 12h14" />,
    trash: (
      <>
        <path d="M4.5 7h15M9 3.5h6l1 3.5H8l1-3.5ZM7 7l1 13h8l1-13M10 10.5v6M14 10.5v6" />
      </>
    ),
    check: <path d="m5 12.5 4.2 4L19 7" />,
    document: (
      <>
        <path d="M6 2.5h8l4 4v15H6v-19Z" />
        <path d="M14 2.5v4h4M9 11h6M9 15h6" />
      </>
    ),
    mail: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="m4 7 8 6 8-6" />
      </>
    ),
    phone: <path d="M7.2 3.5h3l1.3 4-2 1.8c1 2.3 2.9 4.2 5.2 5.2l1.8-2 4 1.3v3c0 2-1.7 3.7-3.7 3.5A14.5 14.5 0 0 1 3.7 7.2c-.2-2 1.5-3.7 3.5-3.7Z" />,
    pin: (
      <>
        <path d="M20 10c0 5-8 11.5-8 11.5S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    link: (
      <>
        <path d="m9.5 14.5 5-5" />
        <path d="M7.5 17.5 6 19a3.5 3.5 0 0 1-5-5l4-4a3.5 3.5 0 0 1 5 0M16.5 6.5 18 5a3.5 3.5 0 0 1 5 5l-4 4a3.5 3.5 0 0 1-5 0" />
      </>
    ),
    download: (
      <>
        <path d="M12 3v12M7.5 10.5 12 15l4.5-4.5" />
        <path d="M5 20.5h14" />
      </>
    ),
  };

  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

function ScoreRing({ score, loading }: { score: number; loading: boolean }) {
  const radius = 37;
  const circumference = 2 * Math.PI * radius;
  const dash = circumference * (Math.min(100, Math.max(0, score)) / 100);

  return (
    <div className="relative size-[94px] shrink-0" aria-label={`Overall score ${score} out of 100`}>
      <svg className="-rotate-90 size-full" viewBox="0 0 94 94">
        <circle cx="47" cy="47" r={radius} fill="none" stroke="#e8eaf2" strokeWidth="7" />
        <circle
          cx="47"
          cy="47"
          r={radius}
          fill="none"
          stroke="#5b5bd6"
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${circumference - dash}`}
          className="transition-all duration-700"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-[22px] font-bold leading-none text-slate-900">{score}</span>
        <span className="mt-1 text-[9px] font-bold uppercase tracking-[0.12em] text-slate-400">
          {loading ? "Updating" : "Score"}
        </span>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  placeholder,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  placeholder?: string;
  onChange: (value: string) => void;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="field-label">{label}</span>
      <input
        className="field"
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
      />
    </label>
  );
}

function TextArea({
  label,
  value,
  onChange,
  placeholder,
  rows = 4,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  rows?: number;
}) {
  return (
    <label className="block">
      <span className="field-label">{label}</span>
      <textarea
        className="field resize-y leading-relaxed"
        rows={rows}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
      />
    </label>
  );
}

function SuggestionsBlock({
  suggestions,
  onApply,
  loading,
}: {
  suggestions: string[];
  onApply: (suggestion: string) => void;
  loading: boolean;
}) {
  if (loading && suggestions.length === 0) {
    return (
      <div className="mt-5 rounded-xl border border-indigo-100 bg-indigo-50/60 p-4">
        <div className="flex items-center gap-2 text-sm font-semibold text-indigo-700">
          <span className="spinner" />
          Preparing AI recommendations…
        </div>
      </div>
    );
  }

  if (suggestions.length === 0) return null;

  return (
    <div className="mt-5 overflow-hidden rounded-xl border border-indigo-100 bg-indigo-50/45">
      <div className="flex items-center gap-2 border-b border-indigo-100 px-4 py-3 text-sm font-semibold text-indigo-800">
        <Icon name="sparkle" className="size-4" />
        AI suggestions
      </div>
      <div className="divide-y divide-indigo-100/80">
        {suggestions.slice(0, 5).map((suggestion, index) => (
          <div className="flex items-start gap-3 px-4 py-3" key={`${suggestion}-${index}`}>
            <p className="min-w-0 flex-1 text-sm leading-6 text-slate-600">{suggestion}</p>
            <button
              type="button"
              className="mt-0.5 shrink-0 rounded-lg bg-white px-3 py-1.5 text-xs font-semibold text-indigo-700 shadow-sm ring-1 ring-indigo-200 transition hover:bg-indigo-600 hover:text-white disabled:opacity-50"
              onClick={() => onApply(suggestion)}
              disabled={loading}
            >
              Apply
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function SectionCard({
  section,
  score,
  suggestions,
  loading,
  children,
  action,
  onApply,
}: {
  section: SectionKey;
  score: number;
  suggestions: string[];
  loading: boolean;
  children: React.ReactNode;
  action?: React.ReactNode;
  onApply: (suggestion: string) => void;
}) {
  return (
    <section className="section-card" id={section}>
      <div className="mb-5 flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <h2 className="truncate text-[17px] font-bold tracking-[-0.01em] text-slate-900">
            {sectionLabels[section]}
          </h2>
          <span
            className={`score-badge ${
              score >= 75
                ? "bg-emerald-50 text-emerald-700 ring-emerald-200"
                : score >= 50
                  ? "bg-amber-50 text-amber-700 ring-amber-200"
                  : "bg-slate-100 text-slate-500 ring-slate-200"
            }`}
          >
            {score}/100
          </span>
        </div>
        {action}
      </div>
      {children}
      <SuggestionsBlock suggestions={suggestions} onApply={onApply} loading={loading} />
    </section>
  );
}

function RemoveButton({ onClick, label }: { onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      className="rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600"
    >
      <Icon name="trash" className="size-[18px]" />
    </button>
  );
}

function AddButton({ onClick, label }: { onClick: () => void; label: string }) {
  return (
    <button type="button" className="add-button" onClick={onClick}>
      <Icon name="plus" className="size-4" />
      Add {label}
    </button>
  );
}

function DividerTitle({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-3 mt-1 flex items-center gap-3">
      <span className="text-xs font-semibold uppercase tracking-[0.1em] text-slate-400">{children}</span>
      <span className="h-px flex-1 bg-slate-100" />
    </div>
  );
}

function ResumePreview({ resume }: { resume: ResumeData }) {
  const info = getPersonalInfo(resume);
  return (
    <div className="resume-paper">
      <header className="border-b-2 border-indigo-600 pb-7">
        <h1 className="font-display text-[34px] font-bold leading-tight tracking-[-0.035em] text-slate-950">
          {info.fullName || "Your Name"}
        </h1>
        <p className="mt-2 text-[11px] font-semibold uppercase tracking-[0.22em] text-indigo-600">
          {resume.experience[0]?.role || "Professional title"}
        </p>
        <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 text-[9px] text-slate-500">
          {info.email && <PreviewContact icon="mail" text={info.email} />}
          {info.phone && <PreviewContact icon="phone" text={info.phone} />}
          {info.location && <PreviewContact icon="pin" text={info.location} />}
        </div>
      </header>

      <div className="mt-7 grid grid-cols-[1fr_2.35fr] gap-7">
        <aside className="border-r border-slate-200 pr-5">
          {resume.skills.length > 0 && (
            <PreviewSection title="Expertise">
              <div className="flex flex-wrap gap-1.5">
                {resume.skills.filter(Boolean).map((skill, index) => (
                  <span
                    className="rounded bg-indigo-50 px-2 py-1 text-[8.5px] font-medium text-indigo-800"
                    key={`${skill}-${index}`}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </PreviewSection>
          )}

          {resume.education.length > 0 && (
            <PreviewSection title="Education">
              <div className="space-y-4">
                {resume.education.map((item) => (
                  <div key={item.id}>
                    <p className="text-[10px] font-bold leading-4 text-slate-800">{item.degree || "Degree"}</p>
                    <p className="mt-0.5 text-[9px] leading-4 text-slate-500">{item.school || "School"}</p>
                    <p className="mt-1 text-[8px] font-medium text-slate-400">
                      {[item.startDate, item.endDate].filter(Boolean).join(" — ")}
                    </p>
                    {item.details && <p className="mt-1 text-[8.5px] leading-4 text-slate-500">{item.details}</p>}
                  </div>
                ))}
              </div>
            </PreviewSection>
          )}

          {resume.certifications.length > 0 && (
            <PreviewSection title="Certifications">
              <div className="space-y-3">
                {resume.certifications.map((item) => (
                  <div key={item.id}>
                    <p className="text-[9.5px] font-bold leading-4 text-slate-800">{item.name || "Certification"}</p>
                    <p className="text-[8px] leading-4 text-slate-500">
                      {[item.issuer, item.date].filter(Boolean).join(" · ")}
                    </p>
                  </div>
                ))}
              </div>
            </PreviewSection>
          )}
        </aside>

        <main>
          {resume.summary && (
            <PreviewSection title="Profile">
              <p className="text-[9.5px] leading-[1.7] text-slate-600">{resume.summary}</p>
            </PreviewSection>
          )}

          {resume.experience.length > 0 && (
            <PreviewSection title="Experience">
              <div className="space-y-5">
                {resume.experience.map((item) => (
                  <div key={item.id}>
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="text-[11px] font-bold leading-4 text-slate-900">{item.role || "Role"}</h3>
                        <p className="text-[9px] font-semibold leading-4 text-indigo-600">
                          {[item.company, item.location].filter(Boolean).join(" · ")}
                        </p>
                      </div>
                      <p className="shrink-0 text-[8px] font-semibold text-slate-400">
                        {[item.startDate, item.endDate].filter(Boolean).join(" — ")}
                      </p>
                    </div>
                    {item.description && (
                      <p className="mt-2 text-[9px] leading-[1.65] text-slate-600">{item.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </PreviewSection>
          )}

          {resume.projects.length > 0 && (
            <PreviewSection title="Selected projects">
              <div className="space-y-4">
                {resume.projects.map((item) => (
                  <div key={item.id}>
                    <div className="flex items-baseline justify-between gap-3">
                      <h3 className="text-[10px] font-bold text-slate-900">{item.name || "Project"}</h3>
                      {item.link && <span className="text-[8px] text-indigo-600">{item.link}</span>}
                    </div>
                    {item.description && <p className="mt-1 text-[9px] leading-[1.65] text-slate-600">{item.description}</p>}
                  </div>
                ))}
              </div>
            </PreviewSection>
          )}
        </main>
      </div>
    </div>
  );
}

function PreviewContact({
  icon,
  text,
}: {
  icon: "mail" | "phone" | "pin" | "link";
  text: string;
}) {
  return (
    <span className="flex items-center gap-1.5">
      <Icon name={icon} className="size-3 text-indigo-500" />
      {text}
    </span>
  );
}

function PreviewSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-6 break-inside-avoid">
      <h2 className="mb-3 text-[9px] font-bold uppercase tracking-[0.2em] text-slate-900">{title}</h2>
      {children}
    </section>
  );
}

export default function App() {
  const [resumeId] = useState(createId);
  const [resume, setResume] = useState<ResumeData>(initialResume);
  const [suggestions, setSuggestions] = useState<Suggestions>(blankSuggestions);
  const [scores, setScores] = useState<Scores>(blankScores);
  const [overallScore, setOverallScore] = useState(0);
  const [loading, setLoading] = useState(false);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [status, setStatus] = useState<"idle" | "saved" | "error">("idle");
  const [error, setError] = useState("");
  const [pdfError, setPdfError] = useState("");
  const [mobileView, setMobileView] = useState<"editor" | "preview">("editor");
  const didMount = useRef(false);
  const skipNextDebounce = useRef(false);
  const requestNumber = useRef(0);
  const latestResume = useRef(resume);
  const personalInfo = getPersonalInfo(resume);

  useEffect(() => {
    latestResume.current = resume;
  }, [resume]);

  const sendResume = useCallback(
    async (data: ResumeData, successStatus: "idle" | "saved" = "idle") => {
      const currentRequest = ++requestNumber.current;
      setLoading(true);
      setError("");
      setStatus("idle");

      try {
        const response = await fetch(API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(getResumePayload(resumeId, data)),
        });

        if (!response.ok) {
          throw new Error(`Request failed with status ${response.status}`);
        }

        const result = await response.json();
        if (result.success === false) {
          throw new Error(result.message || "The resume service could not process this request.");
        }

        if (currentRequest !== requestNumber.current) return;

        const nextSuggestions = { ...blankSuggestions };
        const responseSuggestions = result.suggestions ?? {};
        sectionKeys.forEach((section) => {
          const value =
            responseSuggestions[section] ??
            (section === "personalInfo" ? responseSuggestions.personal_info : undefined);
          if (Array.isArray(value)) nextSuggestions[section] = value.slice(0, 5);
        });
        setSuggestions(nextSuggestions);

        const nextScores = { ...blankScores };
        const responseScores = result.section_scores ?? {};
        sectionKeys.forEach((section) => {
          const value =
            responseScores[section] ??
            (section === "personalInfo" ? responseScores.personal_info : undefined);
          const score = Number(value);
          if (Number.isFinite(score)) nextScores[section] = Math.min(100, Math.max(0, Math.round(score)));
        });
        setScores(nextScores);

        const nextOverall = Number(result.overall_score);
        if (Number.isFinite(nextOverall)) {
          setOverallScore(Math.min(100, Math.max(0, Math.round(nextOverall))));
        }
        setStatus(successStatus);
        if (successStatus === "saved") window.setTimeout(() => setStatus("idle"), 2500);
      } catch (requestError) {
        if (currentRequest !== requestNumber.current) return;
        setError(requestError instanceof Error ? requestError.message : "Unable to connect to the resume service.");
        setStatus("error");
      } finally {
        if (currentRequest === requestNumber.current) setLoading(false);
      }
    },
    [resumeId],
  );

  useEffect(() => {
    if (!didMount.current) {
      didMount.current = true;
      return;
    }
    if (skipNextDebounce.current) {
      skipNextDebounce.current = false;
      return;
    }
    const timer = window.setTimeout(() => sendResume(resume), 1500);
    return () => window.clearTimeout(timer);
  }, [resume, sendResume]);

  const updatePersonal = (field: keyof PersonalInfo, value: string) => {
    setResume((current) => ({
      ...current,
      personalInfo: { ...getPersonalInfo(current), [field]: value },
    }));
  };

  const updateListItem = <K extends "experience" | "education" | "projects" | "certifications">(
    section: K,
    id: string,
    field: keyof ResumeData[K][number],
    value: string,
  ) => {
    setResume((current) => ({
      ...current,
      [section]: current[section].map((item) => (item.id === id ? { ...item, [field]: value } : item)),
    }));
  };

  const removeListItem = (section: "experience" | "education" | "projects" | "certifications", id: string) => {
    setResume((current) => ({
      ...current,
      [section]: current[section].filter((item) => item.id !== id) as never,
    }));
  };

  const addEntry = (section: "experience" | "education" | "projects" | "certifications") => {
    const emptyEntries = {
      experience: {
        id: createId(),
        role: "",
        company: "",
        location: "",
        startDate: "",
        endDate: "",
        description: "",
      },
      education: { id: createId(), school: "", degree: "", startDate: "", endDate: "", details: "" },
      projects: { id: createId(), name: "", link: "", description: "" },
      certifications: { id: createId(), name: "", issuer: "", date: "" },
    };
    setResume((current) => ({
      ...current,
      [section]: [...current[section], emptyEntries[section]] as never,
    }));
  };

  const applySuggestion = (section: SectionKey, suggestion: string) => {
    let next: ResumeData = { ...latestResume.current };

    if (section === "summary") {
      next.summary = suggestion;
    } else if (section === "skills") {
      next.skills = suggestion
        .split(/[,;\n•]+/)
        .map((skill) => skill.trim())
        .filter(Boolean);
    } else if (section === "personalInfo") {
      const lowerSuggestion = suggestion.toLowerCase();
      const fieldLabels: Array<[keyof PersonalInfo, string[]]> = [
        ["email", ["email"]],
        ["phone", ["phone", "mobile"]],
        ["location", ["location", "city"]],
        ["fullName", ["full name", "name"]],
      ];
      const matchedField =
        fieldLabels.find(([, cues]) => cues.some((cue) => lowerSuggestion.includes(cue)))?.[0] ?? "location";
      next.personalInfo = {
        ...getPersonalInfo(next),
        [matchedField]: suggestion.replace(/^[^:]+:\s*/, ""),
      };
    } else if (section === "experience") {
      next.experience = next.experience.length
        ? next.experience.map((item, index) => (index === 0 ? { ...item, description: suggestion } : item))
        : [{ id: createId(), role: "", company: "", location: "", startDate: "", endDate: "", description: suggestion }];
    } else if (section === "education") {
      next.education = next.education.length
        ? next.education.map((item, index) => (index === 0 ? { ...item, details: suggestion } : item))
        : [{ id: createId(), school: "", degree: "", startDate: "", endDate: "", details: suggestion }];
    } else if (section === "projects") {
      next.projects = next.projects.length
        ? next.projects.map((item, index) => (index === 0 ? { ...item, description: suggestion } : item))
        : [{ id: createId(), name: "", link: "", description: suggestion }];
    } else if (section === "certifications") {
      next.certifications = next.certifications.length
        ? next.certifications.map((item, index) => (index === 0 ? { ...item, name: suggestion } : item))
        : [{ id: createId(), name: suggestion, issuer: "", date: "" }];
    }

    latestResume.current = next;
    skipNextDebounce.current = true;
    setResume(next);
    setSuggestions((current) => ({ ...current, [section]: current[section].filter((item) => item !== suggestion) }));
    void sendResume(next);
  };

  const downloadPdf = async () => {
    if (generatingPdf) return;
    setGeneratingPdf(true);
    setPdfError("");
    const pdfWindow = window.open("about:blank", "_blank");

    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...getResumePayload(resumeId, latestResume.current),
          action: "generate_pdf",
        }),
      });

      if (!response.ok) {
        throw new Error(`Request failed with status ${response.status}`);
      }

      const result = await response.json();
      if (result.success === false || !result.pdf_url) {
        throw new Error(result.message || "The PDF service did not return a download URL.");
      }

      const pdfUrl = new URL(result.pdf_url, window.location.href);
      if (!["http:", "https:"].includes(pdfUrl.protocol)) {
        throw new Error("The PDF service returned an invalid download URL.");
      }

      if (pdfWindow) {
        pdfWindow.location.href = pdfUrl.toString();
      } else {
        const link = document.createElement("a");
        link.href = pdfUrl.toString();
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        link.download = result.file_name || "resume.pdf";
        document.body.appendChild(link);
        link.click();
        link.remove();
      }
    } catch (requestError) {
      pdfWindow?.close();
      setPdfError(
        requestError instanceof Error ? requestError.message : "Unable to generate your PDF right now.",
      );
    } finally {
      setGeneratingPdf(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f4f5f9] text-slate-900">
      <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1680px] items-center gap-4 px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-indigo-600 text-white shadow-lg shadow-indigo-600/20">
              <Icon name="document" className="size-5" />
            </div>
            <div className="min-w-0">
              <p className="font-display truncate text-[17px] font-bold tracking-[-0.02em] text-slate-950">Resumind</p>
              <p className="hidden text-[11px] font-medium text-slate-400 sm:block">AI-powered resume studio</p>
            </div>
          </div>

          <div className="ml-auto hidden items-center gap-2 lg:flex">
            {status === "saved" && (
              <span className="mr-2 flex items-center gap-1.5 text-xs font-semibold text-emerald-600">
                <Icon name="check" className="size-4" />
                Saved
              </span>
            )}
            <button
              type="button"
              className="secondary-button"
              onClick={() => void sendResume(latestResume.current, "saved")}
              disabled={loading}
            >
              <Icon name="save" className="size-4" />
              Save resume
            </button>
            <button
              type="button"
              className="download-button"
              onClick={downloadPdf}
              disabled={generatingPdf}
            >
              {generatingPdf ? <span className="spinner" /> : <Icon name="download" className="size-4" />}
              {generatingPdf ? "Generating PDF..." : "Download PDF"}
            </button>
            <button
              type="button"
              className="primary-button"
              onClick={() => void sendResume(latestResume.current)}
              disabled={loading}
            >
              {loading ? <span className="spinner border-white/40 border-t-white" /> : <Icon name="sparkle" className="size-4" />}
              {loading ? "Improving…" : "Get AI suggestions"}
            </button>
          </div>

          <div className="ml-auto lg:ml-5">
            <ScoreRing score={overallScore} loading={loading} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 border-t border-slate-100 px-4 py-3 lg:hidden">
          <button
            type="button"
            className="secondary-button flex-1 justify-center"
            onClick={() => void sendResume(latestResume.current, "saved")}
            disabled={loading}
          >
            <Icon name="save" className="size-4" />
            Save
          </button>
          <button
            type="button"
            className="download-button justify-center"
            onClick={downloadPdf}
            disabled={generatingPdf}
          >
            {generatingPdf ? <span className="spinner" /> : <Icon name="download" className="size-4" />}
            {generatingPdf ? "Generating PDF..." : "Download PDF"}
          </button>
          <button
            type="button"
            className="primary-button col-span-2 justify-center"
            onClick={() => void sendResume(latestResume.current)}
            disabled={loading}
          >
            {loading ? <span className="spinner border-white/40 border-t-white" /> : <Icon name="sparkle" className="size-4" />}
            {loading ? "Improving…" : "AI suggestions"}
          </button>
        </div>
      </header>

      {error && (
        <div className="mx-auto max-w-[1680px] px-4 pt-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <span>We couldn’t update your scores. {error}</span>
            <button className="font-semibold underline underline-offset-2" onClick={() => void sendResume(latestResume.current)}>
              Try again
            </button>
          </div>
        </div>
      )}

      {pdfError && (
        <div className="mx-auto max-w-[1680px] px-4 pt-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <span>We couldn’t generate your PDF. {pdfError}</span>
            <button className="font-semibold underline underline-offset-2" onClick={() => void downloadPdf()}>
              Try again
            </button>
          </div>
        </div>
      )}

      <div className="mx-auto max-w-[1680px] px-4 py-5 sm:px-6 lg:px-8">
        <div className="mb-4 grid grid-cols-2 rounded-xl bg-slate-200/70 p-1 lg:hidden">
          <button
            className={`rounded-lg py-2 text-sm font-semibold transition ${
              mobileView === "editor" ? "bg-white text-slate-900 shadow-sm" : "text-slate-500"
            }`}
            onClick={() => setMobileView("editor")}
          >
            Editor
          </button>
          <button
            className={`rounded-lg py-2 text-sm font-semibold transition ${
              mobileView === "preview" ? "bg-white text-slate-900 shadow-sm" : "text-slate-500"
            }`}
            onClick={() => setMobileView("preview")}
          >
            Live preview
          </button>
        </div>

        <main className="grid items-start gap-6 lg:grid-cols-[minmax(0,1.18fr)_minmax(470px,0.82fr)] xl:gap-8">
          <div className={`space-y-4 ${mobileView === "preview" ? "hidden lg:block" : ""}`}>
            <div className="mb-6">
              <p className="text-xs font-bold uppercase tracking-[0.14em] text-indigo-600">Resume editor</p>
              <h1 className="font-display mt-1.5 text-2xl font-bold tracking-[-0.025em] text-slate-950">
                Build a resume that gets noticed.
              </h1>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">
                Add your experience and use AI recommendations to make every section stronger.
              </p>
            </div>

            <SectionCard
              section="personalInfo"
              score={scores.personalInfo}
              suggestions={suggestions.personalInfo}
              loading={loading}
              onApply={(value) => applySuggestion("personalInfo", value)}
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Full name" value={personalInfo.fullName} onChange={(value) => updatePersonal("fullName", value)} />
                <Field label="Email" type="email" value={personalInfo.email} onChange={(value) => updatePersonal("email", value)} />
                <Field label="Phone" value={personalInfo.phone} onChange={(value) => updatePersonal("phone", value)} />
                <Field label="Location" value={personalInfo.location} onChange={(value) => updatePersonal("location", value)} />
              </div>
            </SectionCard>

            <SectionCard
              section="summary"
              score={scores.summary}
              suggestions={suggestions.summary}
              loading={loading}
              onApply={(value) => applySuggestion("summary", value)}
            >
              <TextArea
                label="Summary"
                value={resume.summary}
                onChange={(value) => setResume((current) => ({ ...current, summary: value }))}
                placeholder="Describe your experience, strengths, and goals…"
                rows={5}
              />
            </SectionCard>

            <SectionCard
              section="experience"
              score={scores.experience}
              suggestions={suggestions.experience}
              loading={loading}
              action={<AddButton label="experience" onClick={() => addEntry("experience")} />}
              onApply={(value) => applySuggestion("experience", value)}
            >
              <div className="space-y-6">
                {resume.experience.map((item, index) => (
                  <div key={item.id}>
                    <div className="flex items-center justify-between">
                      <DividerTitle>Position {index + 1}</DividerTitle>
                      <RemoveButton label="Remove experience" onClick={() => removeListItem("experience", item.id)} />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field label="Job title" value={item.role} onChange={(value) => updateListItem("experience", item.id, "role", value)} />
                      <Field label="Company" value={item.company} onChange={(value) => updateListItem("experience", item.id, "company", value)} />
                      <Field label="Location" value={item.location} onChange={(value) => updateListItem("experience", item.id, "location", value)} />
                      <div className="grid grid-cols-2 gap-3">
                        <Field label="Start" value={item.startDate} onChange={(value) => updateListItem("experience", item.id, "startDate", value)} />
                        <Field label="End" value={item.endDate} onChange={(value) => updateListItem("experience", item.id, "endDate", value)} />
                      </div>
                      <div className="sm:col-span-2">
                        <TextArea label="Impact & achievements" value={item.description} onChange={(value) => updateListItem("experience", item.id, "description", value)} rows={4} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>

            <SectionCard
              section="education"
              score={scores.education}
              suggestions={suggestions.education}
              loading={loading}
              action={<AddButton label="education" onClick={() => addEntry("education")} />}
              onApply={(value) => applySuggestion("education", value)}
            >
              <div className="space-y-6">
                {resume.education.map((item, index) => (
                  <div key={item.id}>
                    <div className="flex items-center justify-between">
                      <DividerTitle>Education {index + 1}</DividerTitle>
                      <RemoveButton label="Remove education" onClick={() => removeListItem("education", item.id)} />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field label="School" value={item.school} onChange={(value) => updateListItem("education", item.id, "school", value)} />
                      <Field label="Degree" value={item.degree} onChange={(value) => updateListItem("education", item.id, "degree", value)} />
                      <Field label="Start year" value={item.startDate} onChange={(value) => updateListItem("education", item.id, "startDate", value)} />
                      <Field label="End year" value={item.endDate} onChange={(value) => updateListItem("education", item.id, "endDate", value)} />
                      <div className="sm:col-span-2">
                        <Field label="Additional details" value={item.details} onChange={(value) => updateListItem("education", item.id, "details", value)} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>

            <SectionCard
              section="skills"
              score={scores.skills}
              suggestions={suggestions.skills}
              loading={loading}
              onApply={(value) => applySuggestion("skills", value)}
            >
              <TextArea
                label="Skills"
                value={resume.skills.join(", ")}
                onChange={(value) =>
                  setResume((current) => ({
                    ...current,
                    skills: value.split(",").map((skill) => skill.trimStart()),
                  }))
                }
                placeholder="Product design, Leadership, Figma…"
                rows={3}
              />
              <p className="mt-2 text-xs text-slate-400">Separate skills with commas.</p>
            </SectionCard>

            <SectionCard
              section="projects"
              score={scores.projects}
              suggestions={suggestions.projects}
              loading={loading}
              action={<AddButton label="project" onClick={() => addEntry("projects")} />}
              onApply={(value) => applySuggestion("projects", value)}
            >
              <div className="space-y-6">
                {resume.projects.map((item, index) => (
                  <div key={item.id}>
                    <div className="flex items-center justify-between">
                      <DividerTitle>Project {index + 1}</DividerTitle>
                      <RemoveButton label="Remove project" onClick={() => removeListItem("projects", item.id)} />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field label="Project name" value={item.name} onChange={(value) => updateListItem("projects", item.id, "name", value)} />
                      <Field label="Project link" value={item.link} onChange={(value) => updateListItem("projects", item.id, "link", value)} />
                      <div className="sm:col-span-2">
                        <TextArea label="Description" value={item.description} onChange={(value) => updateListItem("projects", item.id, "description", value)} rows={3} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>

            <SectionCard
              section="certifications"
              score={scores.certifications}
              suggestions={suggestions.certifications}
              loading={loading}
              action={<AddButton label="certification" onClick={() => addEntry("certifications")} />}
              onApply={(value) => applySuggestion("certifications", value)}
            >
              <div className="space-y-6">
                {resume.certifications.map((item, index) => (
                  <div key={item.id}>
                    <div className="flex items-center justify-between">
                      <DividerTitle>Certification {index + 1}</DividerTitle>
                      <RemoveButton label="Remove certification" onClick={() => removeListItem("certifications", item.id)} />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-3">
                      <Field label="Certification" value={item.name} onChange={(value) => updateListItem("certifications", item.id, "name", value)} />
                      <Field label="Issuer" value={item.issuer} onChange={(value) => updateListItem("certifications", item.id, "issuer", value)} />
                      <Field label="Date" value={item.date} onChange={(value) => updateListItem("certifications", item.id, "date", value)} />
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>
          </div>

          <aside className={`lg:sticky lg:top-[126px] ${mobileView === "editor" ? "hidden lg:block" : ""}`}>
            <div className="mb-3 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.14em] text-indigo-600">Live preview</p>
                <p className="mt-1 text-xs text-slate-400">Updates as you type</p>
              </div>
              <span className="rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-slate-500 shadow-sm ring-1 ring-slate-200">
                A4 format
              </span>
            </div>
            <div className="preview-shell">
              <ResumePreview resume={resume} />
            </div>
          </aside>
        </main>
      </div>
    </div>
  );
}
